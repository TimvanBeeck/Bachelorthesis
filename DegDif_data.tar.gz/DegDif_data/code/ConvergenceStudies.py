"""
This file can be used to replicate the convergence studies on a square and a
circle geometry. The approximation errors in an energy like norm, in the
L2-norm, and the error of the best L2-approximation are calculated and written
into an output file. 
"""


# ------------------------------ LOAD LIBRARIES -------------------------------
from netgen.geom2d import SplineGeometry
from ngsolve import *
import os
import sys
from calculateRHS import calculate_rhs
from SolveProblem import Solve
#remove the following for the circle geometry
from ngsolve.meshes import *

#Definition of the differential operator du
du = lambda u,w: InnerProduct(u,grad(w))

# ------------------------------ PRELIMINARIES --------------------------------
#filename of the output file (might have to be adjusted)
def filename(errorName,u,k):
    name = './Results/'+str(errorName)+'errors'+str(u)+str(k)+'.txt'
    return name

def writeFile(filename,errors):
    textfile = open(filename, "w")
    for element in errors:
        textfile.write(str(element) + "\n")
    textfile.close()


# -------------------------------- PARAMETERS ---------------------------------
#exact solution
gaussp = CoefficientFunction(exp(-6*((x+0.5)*(x+0.5)+y*y))-exp(-6*((x-0.5)*(x-0.5)+y*y)))
#three velocitiy fields: one constant, one rotation, one vortex
u0 = CoefficientFunction((1,1))
u1 = CoefficientFunction((-0.75*y,0.75*x))
u2 = CoefficientFunction((2*y*(1-x*x),-2*x*(1-y*y)))
velocities = [u0,u1,u2]

#specification of the number of mesh refinements
refinements = [(n+1) for n in range(8)]

# ----------------------------------- MAIN ------------------------------------
for u in range(0,3):
    for k in range(1,5):
        l2errors = []
        bl2errors = []
        werrors = []
        uC = velocities[u]
        for n in refinements:
            #set up the (square) geometry
            square = SplineGeometry()
            square.AddRectangle((-1.0, -1.0), (1.0, 1.0))
            mesh = MakeStructured2DMesh(quads=False, nx=2**n, ny=2**n,mapping = lambda x,y: (2*x-1,2*y-1))

            '''
            #For the circle geometry -> does not need ngsolve.meshes
            maxh = 1
            geo = SplineGeometry()
            geo.AddCircle(c=(0,0),r=1,bc="circle")
            ngmesh = geo.GenerateMesh(maxh=maxh)
            for i in range(n):
                ngmesh.Refine()
            mesh = Mesh(ngmesh)
            mesh.Curve(7)
            '''
            #initialize penalization parameter and density
            lamb = 10*(k+1)**2
            rho = 1

            #calculation of the discrete solution and the best L2-approximation
            gfu, gfu2, exactGrad, cond, condPre = Solve(k,gaussp,rho,uC,lamb,mesh,True,True,False)

            L2error = sqrt(Integrate((gfu-gaussp)**2,mesh))
            BL2error = sqrt(Integrate((gfu2-gaussp)**2,mesh))
            Werror = L2error + sqrt(Integrate((du(uC,gfu)-uC*exactGrad)**2,mesh))
            l2errors.append(L2error)
            bl2errors.append(BL2error)
            werrors.append(Werror)

        #writes the errors to an output file
        writeFile(filename("L2",u,k),l2errors)
        writeFile(filename("bestl2",u,k),bl2errors)
        writeFile(filename("W",u,k),werrors)
