"""
This file calculates the condition numbers of the stiffness matrix and the
diagonally preconditioned stiffness matrix using the built in Eigenvalue
Solver in NGSolve. We consider different penalization parameters. 
"""


# ------------------------------ LOAD LIBRARIES -------------------------------
from netgen.geom2d import SplineGeometry
from ngsolve import *
import os
import sys
from calculateRHS import calculate_rhs
from SolveProblem import Solve
from ngsolve.meshes import *

#Definition of the differential operator du
du = lambda u,w: InnerProduct(u,grad(w))


# ------------------------------ PRELIMINARIES --------------------------------
#filename of the output file (might have to be adjusted)
def filename(u,k,pre=False):
    if pre == False:
        name = './CondNumbers/VF'+str(u)+str(k)+'.txt'
    else:
        name = './CondNumbers/PreVF'+str(u)+str(k)+'.txt'
    return name

#writes the calculated errors in a txt file
def writeFile(filename,cns):
    textfile = open(filename, "w")
    for element in cns:
        textfile.write(str(element) + "\n")
    textfile.close()

# -------------------------------- PARAMETERS ---------------------------------
#exact solution
gaussp = CoefficientFunction(exp(-6*((x+0.5)*(x+0.5)+y*y))-exp(-6*((x-0.5)*(x-0.5)+y*y)))
#three velocitiy fields: one constant, one rotation, one vortex
u0 = CoefficientFunction((1,1))
u1 = CoefficientFunction((-0.75*y,0.75*x))
u2 = CoefficientFunction((2*y*(1-x*x),-2*x*(1-y*y)))
velocities = [u0,u1,u2]


#different penalization parameters
lams = [2**n for n in range(14)]

# ----------------------------------- MAIN ------------------------------------
#setup of the (square) geometry
n = 6
square = SplineGeometry()
square.AddRectangle((-1.0, -1.0), (1.0, 1.0))
mesh = MakeStructured2DMesh(quads=False, nx=2**n, ny=2**n,mapping = lambda x,y: (2*x-1,2*y-1))
for u in range(0,3):
    for k in range(1,5):
        cs = []
        csp = []
        for lamb in lams:
            uC = velocities[u]
            #calculates the condition numbers
            gfu, gfu2, exactGrad, cond, condPre = Solve(k,gaussp,1,uC,lamb,mesh,True,True,True)
            cs.append(cond)
            csp.append(condPre)


        writeFile(filename(u,k),cs)
        writeFile(filename(u,k,True),csp)
