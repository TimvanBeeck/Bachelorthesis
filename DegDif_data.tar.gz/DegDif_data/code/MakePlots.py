"""
This file can be used to generate the plots from the data. Currently, it uses
the data for the non-constant density, which has to be adjusted when
the other results are considered.
"""


# ------------------------------ LOAD LIBRARIES -------------------------------
from ngsolve import *
import matplotlib.pyplot as plt
import os
import sys

# ------------------------------ PRELIMINARIES --------------------------------
#filename of the output file (might have to be adjusted)
def filename(errorName,u,k,r):
    name = './data/CircleGeometry/NonConstantDensity/RC'+str(r)+'/'+str(errorName)+'errors'+str(u)+str(k)+'.txt'
    return name

#calculates the reference oders of convergence
def ref(k,start,l):
    reference = []
    reference.append(start)
    for i in range(l):
        reference.append(reference[i]*1/exp(k*log(2)))
    return reference

# ----------------------------------- MAIN ------------------------------------
#inputs are the errors, an array with the refinements, the velocity field,
# an interger for the coeffiecient in the non-constant density, and a boolean dr
# being 1 when the W-errors are used and 0 for the L2- ones.
def plotting(errors,refs,u,rc,dr=1):
    if dr == 1:
        dest = './Plots/RC'+str(rc)+'/WPlot'+str(u)+'.pdf'
    else:
        dest = './Plots/RC'+str(rc)+'/L2Plot'+str(u)+'.pdf'

    #plot parameters
    plt.rc('font', family='serif', serif='Times',size=15)
    plt.rc('text', usetex=True)
    plt.rc('xtick', labelsize=15)
    plt.rc('ytick', labelsize=15)
    plt.rc('axes', labelsize=15)
    fig, ax = plt.subplots()

    j = dr

    #for convenience, all errors are stored in a single array below, here they are separated again
    k1errors = errors[:6]
    k2errors = errors[6:12]
    k3errors = errors[12:18]
    k4errors = errors[18:]

    """
    #for the square geometry with more refinements
    k1errors = errors[:8]
    k2errors = errors[8:16]
    k3errors = errors[16:24]
    k4errors = errors[24:]
    """

    #plotting the errors for k = 1,...,4 together with the reference order of convergence
    lw = 2
    mks = 4
    plt.plot(refs,k1errors,'-v',linewidth=lw,markersize=mks)
    plt.plot(refs,ref(j,k1errors[0],len(refs)-1),linewidth=lw,color='grey',linestyle='dashed')
    j += 1

    plt.plot(refs,k2errors,'-o',linewidth=lw,markersize=mks)
    plt.plot(refs,ref(j,k2errors[0],len(refs)-1),linewidth=lw,color='grey',linestyle='dotted')
    j += 1

    plt.plot(refs,k3errors,'-h',linewidth=lw,markersize=mks)
    plt.plot(refs,ref(j,k3errors[0],len(refs)-1),linewidth=lw,color='grey',linestyle='dashdot')
    j += 1

    plt.plot(refs,k4errors,'-d',linewidth=lw,markersize=mks)
    plt.plot(refs,ref(j,k4errors[0],len(refs)-1),linewidth=lw,color='grey',linestyle=(0, (3, 5, 1, 5, 1, 5)))

    #labeling of the plots
    labels = []
    for k in range(1,5):
        labels.append("k = "+str(k))
        if dr == 1:
            labels.append("O("+str(k)+")")
        else:
            labels.append("O("+str(k+1)+")")

    leg = ax.legend(labels, loc="lower center", bbox_to_anchor=(0.5, -0.25),frameon=False,ncol=4)

    if dr == 1:
        ax.set_ylabel('$e_{W}$',fontsize=18)
    else:
        ax.set_ylabel('$e_{L^2}$',fontsize=18)


    #semi-log scale
    ax.set_yscale('log')
    ax.tick_params(direction='in',bottom=True,left=True,right=True,top=True)

    #sets figure size
    fig.set_size_inches(6,5)
    #saves the figure
    fig.savefig(dest,bbox_inches='tight')

#different
rcs = [4,8,12,16]

#looping over each coeffiecient and each vector field
for rc in rcs:
    for u in range(0,3):
        l2errors = []
        werrors = []
        for k in range(1,5):
            l2name = filename("L2",u,k,rc)
            Wname = filename("W",u,k,rc)

            #reads data
            with open(l2name) as f:
                lines = f.readlines()
            for i in range(len(lines)):
                l2errors.append(float(lines[i].strip()))

            with open(Wname) as f:
                lines = f.readlines()
            for i in range(len(lines)):
                werrors.append(float(lines[i].strip()))

        #refinements
        refs = [(n+1) for n in range(6)]

        #plots W- and L2-errors
        plotting(werrors,refs,u,rc)
        plotting(l2errors,refs,u,rc,2)
