"""
This file solves the discrete problem with NGSolve. Furthermore, if wanted, we
can calculate the best L2-approximation and the condition numbers of the
stiffness matrix and the diagonally preconditioned stiffness matrix. 
"""



# ------------------------------ LOAD LIBRARIES -------------------------------
from ngsolve import *
from ngsolve.la import EigenValues_Preconditioner
from calculateRHS import calculate_rhs

#Definition of the differential operator du
du = lambda u,w: InnerProduct(u,grad(w))

# ----------------------------------- MAIN ------------------------------------
def Solve(k,exact,rho,uC,lamb,mesh,rhoVol = True,bl2 = False,cn = False):
    #set up the FE spaces
    fes = L2(mesh, order=k, dgjumps=True)
    w,v = fes.TnT()
    gfu = GridFunction(fes)

    n = specialcf.normal(2)
    h = specialcf.mesh_size

    #definition of jump and average operators
    jump_w = w-w.Other()
    jump_v = v-v.Other()
    avg_duw = 0.5*(du(uC,w)+du(uC,w.Other()))
    avg_duv = 0.5*(du(uC,v)+du(uC,v.Other()))

    #increased integration order to improve accuracy
    dX = dx(bonus_intorder = 2)
    dS = ds(bonus_intorder = 2)

    #calculation of the right hand side and the exact gradient
    rhs,exactGrad = calculate_rhs(uC,exact,rho,rhoVol)

    #set up of the bilinear form
    a = BilinearForm(fes,symmetric=True)
    if rhoVol == True:
        a += rho*w*v*dx
    else:
        a += w*v*dx
    a += rho*du(uC,w)*du(uC,v)*dX
    a += uC*n*-rho*avg_duw*jump_v*dX(skeleton=True)
    a += uC*n*-rho*avg_duv*jump_w*dX(skeleton=True)
    a += rho*lamb*1/h*(uC*n)*(uC*n)*jump_w*jump_v*dX(skeleton=True)
    a += uC*n*-rho*du(uC,w)*v*dS(skeleton=True)
    a += uC*n*-rho*du(uC,v)*w*dS(skeleton=True)
    a += rho*lamb*1/h*(uC*n)*(uC*n)*w*v*dS(skeleton=True)

    #setting up the linear form
    f = LinearForm(fes)
    f += rhs*v*dX
    f += uC*n*-rho*du(uC,v)*exact*dS(skeleton=True)
    f += rho*lamb*1/h*(uC*n)*(uC*n)*exact*v*dS(skeleton=True)

    #assembling
    a.Assemble()
    f.Assemble()

    #solving the linear system
    aInv = a.mat.Inverse(freedofs=fes.FreeDofs(),inverse="sparsecholesky")
    gfu.vec[:] = 0.0
    gfu.vec.data = aInv * f.vec

    #if specified, calculation of the condition numbers
    if cn == True:
        lams = EigenValues_Preconditioner(a.mat,IdentityMatrix(a.space.ndof))
        Prelams = EigenValues_Preconditioner(a.mat,a.mat.CreateSmoother())
        cond = lams[-1]/lams[0]
        condPre = Prelams[-1]/Prelams[0]
    else:
        cond = 'N/A'
        condPre = 'N/A'

    #if specified, calculation of the best L2-approximation
    if bl2 == True:
        w1,v1 = fes.TnT()
        gfu2 = GridFunction(fes)

        b = BilinearForm(fes,symmetric=True)
        b += w1*v1*dX

        l = LinearForm(fes)
        l += exact*v1*dX

        b.Assemble()
        l.Assemble()

        gfu2.vec[:] = 0.0
        gfu2.vec.data = b.mat.Inverse(freedofs=fes.FreeDofs(),inverse="sparsecholesky")*l.vec
        #returns the discrete approximation, the best L2-approximation, the
        #exact gradient and the condition numbers
        return gfu,gfu2,exactGrad, cond, condPre
    else:
        #returns the discrete approximation,the exact gradient and
        #the condition numbers
        return gfu, exactGrad, cond, condPre
