"""
This file calculates the right hand side of our model problem given a vector
field, an exact solution and a density. The parameter rhoVol controls whether
the volume term in the problem is scaled with the density.
"""


# ------------------------------ LOAD LIBRARIES -------------------------------
from ngsolve import *


# ----------------------------------- MAIN ------------------------------------
def calculate_rhs(u,exact,rho,rhoVol=False):
    #calculation of the dyadic product of u with itself
    umat = CoefficientFunction(u,dims=(2,1))
    uTen = umat*umat.trans
    #calculation of the exact gradient, the diffusion term and the divergence
    exactGrad = (exact.Diff(x),exact.Diff(y))
    exactDiffusion = rho*uTen*exactGrad
    exactDiv = exactDiffusion[0].Diff(x)+exactDiffusion[1].Diff(y)
    if rhoVol == True:
        rhs = rho*exact-exactDiv
    else:
        rhs = exact-exactDiv
    #returns a right hand side and the exact gradient
    return rhs, exactGrad
